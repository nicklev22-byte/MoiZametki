package ru.moizametki.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import android.app.NotificationChannel;
import android.app.NotificationManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_CHOOSER = 21;
    private static final int NOTIFICATION_PERMISSION = 22;
    static final String PREFS = "notes_store";
    static final String DATA_KEY = "sections_json";
    static final String CHANNEL_ID = "notes_reminders";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(244,246,248));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(244,246,248));
        if (Build.VERSION.SDK_INT >= 23) {
            getWindow().getDecorView().setSystemUiVisibility(android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        }
        createNotificationChannel();
        askNotificationPermission();
        webView = new WebView(this);
        webView.setBackgroundColor(android.graphics.Color.rgb(244,246,248));
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        webView.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("image/*");
                startActivityForResult(Intent.createChooser(intent, "Выбрать изображение"), FILE_CHOOSER);
                return true;
            }
        });
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel ch = new NotificationChannel(CHANNEL_ID, "Напоминания о заметках", NotificationManager.IMPORTANCE_DEFAULT);
            ch.setDescription("Уведомления по дате и времени заметок");
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER && fileCallback != null) {
            Uri[] results = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) results = new Uri[]{data.getData()};
            fileCallback.onReceiveValue(results); fileCallback = null;
        }
    }

    @Override protected void onNewIntent(Intent intent) { super.onNewIntent(intent); setIntent(intent); if (webView != null) webView.evaluateJavascript("window.location.reload()", null); }
    @Override public void onBackPressed() { if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }

    public class AndroidBridge {
        @JavascriptInterface public String loadData() {
            return getSharedPreferences(PREFS, MODE_PRIVATE).getString(DATA_KEY, "");
        }
        @JavascriptInterface public void saveData(String json) {
            getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(DATA_KEY, json).apply();
            runOnUiThread(() -> { NotesWidgetProvider.updateAll(MainActivity.this); scheduleAll(json); });
        }
        @JavascriptInterface public String getLaunchTarget() {
            Intent i = getIntent();
            if (i == null || !i.hasExtra("sectionId") || !i.hasExtra("noteId")) return "null";
            JSONObject obj = new JSONObject();
            try { obj.put("sectionId", i.getStringExtra("sectionId")); obj.put("noteId", i.getStringExtra("noteId")); } catch (Exception ignored) {}
            i.removeExtra("sectionId"); i.removeExtra("noteId");
            return obj.toString();
        }
    }

    private void scheduleAll(String json) {
        try {
            JSONArray sections = new JSONArray(json);
            AlarmManager am = (AlarmManager)getSystemService(ALARM_SERVICE);
            for (int i=0;i<sections.length();i++) {
                JSONObject s=sections.getJSONObject(i); JSONArray notes=s.optJSONArray("notes"); if(notes==null) continue;
                for(int j=0;j<notes.length();j++) {
                    JSONObject n=notes.getJSONObject(j); String date=n.optString("date",""); String time=n.optString("time","");
                    if(date.isEmpty() || time.isEmpty()) continue;
                    SimpleDateFormat fmt=new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.US); fmt.setLenient(false);
                    Date d; try { d=fmt.parse(date+" "+time); } catch(ParseException ex) { continue; }
                    if(d==null || d.getTime()<=System.currentTimeMillis()) continue;
                    int id=(s.optString("id","")+n.optString("id","")).hashCode() & 0x7fffffff;
                    Intent intent=new Intent(this, ReminderReceiver.class); intent.putExtra("noteText",n.optString("text","Напоминание")); intent.putExtra("sectionName",s.optString("name","Мои заметки")); intent.putExtra("noteId",n.optString("id",""));
                    PendingIntent pi=PendingIntent.getBroadcast(this,id,intent,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
                    try { if(Build.VERSION.SDK_INT>=23) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,d.getTime(),pi); else am.setExact(AlarmManager.RTC_WAKEUP,d.getTime(),pi); }
                    catch(SecurityException ex) { am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,d.getTime(),pi); }
                }
            }
        } catch(Exception ignored) {}
    }
}
