package ru.moizametki.app;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.view.View;
import android.widget.RemoteViews;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.text.TextUtils;

import org.json.JSONArray;
import org.json.JSONObject;

public class NotesWidgetProvider extends AppWidgetProvider {
    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] ids) { for(int id:ids) updateOne(context,manager,id); }
    static void updateAll(Context context) { AppWidgetManager m=AppWidgetManager.getInstance(context); ComponentName c=new ComponentName(context,NotesWidgetProvider.class); int[] ids=m.getAppWidgetIds(c); for(int id:ids) updateOne(context,m,id); }
    private static void updateOne(Context context, AppWidgetManager manager, int widgetId) {
        RemoteViews views=new RemoteViews(context.getPackageName(),R.layout.widget_notes);
        Intent open=new Intent(context,MainActivity.class); open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent openPi=PendingIntent.getActivity(context,widgetId,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.widget_title,openPi); views.setOnClickPendingIntent(R.id.widget_open,openPi);
        views.removeAllViews(R.id.widget_items);
        String raw=context.getSharedPreferences(MainActivity.PREFS,Context.MODE_PRIVATE).getString(MainActivity.DATA_KEY,"");
        int count=0;
        try {
            JSONArray sections=new JSONArray(raw);
            for(int i=0;i<sections.length();i++) {
                JSONObject s=sections.getJSONObject(i); String name=s.optString("name","Раздел"); String color=s.optString("color","#ffffff");
                int bg=Color.WHITE; try { bg=Color.parseColor(color); } catch(Exception ignored) {}
                RemoteViews heading=new RemoteViews(context.getPackageName(),android.R.layout.simple_list_item_1);
                heading.setTextViewText(android.R.id.text1,"▸ "+name); heading.setTextColor(android.R.id.text1,Color.rgb(32,36,43)); heading.setInt(android.R.id.text1,"setBackgroundColor",bg); heading.setTextViewTextSize(android.R.id.text1,2,14);
                views.addView(R.id.widget_items,heading); count++;
                JSONArray notes=s.optJSONArray("notes"); if(notes==null) continue;
                for(int j=0;j<notes.length() && count<40;j++) {
                    JSONObject n=notes.getJSONObject(j); String txt=n.optString("text","").replace('\n',' '); if(txt.length()>100)txt=txt.substring(0,97)+"…";
                    RemoteViews row=new RemoteViews(context.getPackageName(),android.R.layout.simple_list_item_1);
                    row.setTextViewText(android.R.id.text1,"  • "+txt); row.setTextColor(android.R.id.text1,Color.rgb(32,36,43)); row.setInt(android.R.id.text1,"setBackgroundColor",Color.argb(235,255,255,255)); row.setTextViewTextSize(android.R.id.text1,2,12);
                    Intent edit=new Intent(context,MainActivity.class); edit.putExtra("sectionId",s.optString("id","")); edit.putExtra("noteId",n.optString("id","")); edit.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
                    PendingIntent editPi=PendingIntent.getActivity(context, (s.optString("id","")+n.optString("id","")).hashCode(), edit, PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
                    row.setOnClickPendingIntent(android.R.id.text1,editPi); views.addView(R.id.widget_items,row); count++;
                }
            }
            if(count==0) { RemoteViews empty=new RemoteViews(context.getPackageName(),android.R.layout.simple_list_item_1); empty.setTextViewText(android.R.id.text1,"Добавьте заметки в приложении"); views.addView(R.id.widget_items,empty); }
        } catch(Exception e) { RemoteViews empty=new RemoteViews(context.getPackageName(),android.R.layout.simple_list_item_1); empty.setTextViewText(android.R.id.text1,"Откройте приложение и добавьте заметки"); views.addView(R.id.widget_items,empty); }
        manager.updateAppWidget(widgetId,views);
    }
}
