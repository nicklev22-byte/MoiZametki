package ru.moizametki.app;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.widget.RemoteViews;
import org.json.JSONArray;
import org.json.JSONObject;

public class NotesWidgetProvider extends AppWidgetProvider {
    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        for (int id : ids) updateOne(context, manager, id);
    }
    public static void updateAll(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        int[] ids = manager.getAppWidgetIds(new ComponentName(context, NotesWidgetProvider.class));
        for (int id : ids) updateOne(context, manager, id);
    }
    private static void updateOne(Context context, AppWidgetManager manager, int widgetId) {
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_notes);
        Intent open = new Intent(context, MainActivity.class);
        open.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent openPi = PendingIntent.getActivity(context, widgetId, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.widget_title, openPi);
        views.setOnClickPendingIntent(R.id.widget_open, openPi);
        String raw = context.getSharedPreferences(MainActivity.PREFS, Context.MODE_PRIVATE)
                .getString(MainActivity.DATA_KEY, "");
        StringBuilder text = new StringBuilder();
        int shown = 0;
        try {
            if (raw.trim().isEmpty()) throw new Exception("empty");
            JSONArray sections = new JSONArray(raw);
            for (int i = 0; i < sections.length() && shown < 12; i++) {
                JSONObject section = sections.optJSONObject(i);
                if (section == null) continue;
                JSONArray notes = section.optJSONArray("notes");
                if (notes == null || notes.length() == 0) continue;
                if (text.length() > 0) text.append("\n");
                text.append("● ").append(section.optString("name", "Раздел")).append("\n");
                for (int j = 0; j < notes.length() && shown < 12; j++) {
                    JSONObject note = notes.optJSONObject(j);
                    if (note == null) continue;
                    String line = note.optString("text", "").replace('\n', ' ').trim();
                    if (line.length() > 115) line = line.substring(0, 112) + "…";
                    if (!line.isEmpty()) {
                        text.append("  • ").append(line);
                        String date = note.optString("date", "");
                        String time = note.optString("time", "");
                        if (!date.isEmpty() || !time.isEmpty()) text.append("  🔔 ").append(date).append(" ").append(time).toString();
                        text.append("\n"); shown++;
                    }
                }
            }
            if (shown == 0) text.append("Пока нет заметок. Открой приложение и добавь первую.");
            else if (shown >= 12) text.append("\nОткрой приложение, чтобы увидеть остальные заметки.");
        } catch (Exception e) {
            text.setLength(0);
            text.append("Открой приложение один раз, чтобы загрузить заметки в виджет.");
        }
        views.setTextViewText(R.id.widget_content, text.toString().trim());
        views.setInt(R.id.widget_content, "setTextColor", Color.rgb(32, 36, 43));
        manager.updateAppWidget(widgetId, views);
    }
}
